import 'package:flutter/material.dart';

   const kItemNameStyle =
  TextStyle(fontWeight: FontWeight.bold, fontSize: 18);

   const kItemColorStyle =
  TextStyle(fontWeight: FontWeight.w400, fontSize: 15,color: Colors.black54);

   const kItemPriceStyle =
  TextStyle(fontWeight: FontWeight.w500, fontSize: 16);
